package com.novoda.redditvideos

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import com.novoda.redditvideos.support.view.inflateDetached
import com.novoda.redditvideos.support.view.load
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_video_entry.*
import kotlinx.android.synthetic.main.state_failure.*

internal class VideoFeedAdapter : RecyclerView.Adapter<VideoFeedViewHolder>() {

    var state: VideoFeedState = VideoFeedState.Loading
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, position: Int) = when (state) {
        is VideoFeedState.Loading -> Loading(parent)
        is VideoFeedState.Idle -> VideoItem(parent)
        is VideoFeedState.Failure -> Failure(parent)
    }

    override fun getItemCount() = (state as? VideoFeedState.HasVideos)?.videos?.size ?: 1

    override fun onBindViewHolder(viewHolder: VideoFeedViewHolder, position: Int) = when (viewHolder) {
        is VideoItem -> viewHolder.bind((state as VideoFeedState.Idle).videos[position])
        is Loading -> Unit //
        is Failure -> viewHolder.bind(state as VideoFeedState.Failure)
    }

}

sealed class VideoFeedViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), LayoutContainer {
    override val containerView: View = itemView
}

private class Loading(parent: ViewGroup) : VideoFeedViewHolder(parent.inflateDetached(R.layout.state_loading))
private class VideoItem(parent: ViewGroup) : VideoFeedViewHolder(parent.inflateDetached(R.layout.item_video_entry))
private class Failure(parent: ViewGroup) : VideoFeedViewHolder(parent.inflateDetached(R.layout.state_failure))

private fun VideoItem.bind(videoEntry: VideoEntry) {
    title.text = videoEntry.title
    thumbnail.load(videoEntry.thumbnail)
}

private fun Failure.bind(failure: VideoFeedState.Failure) {
    errorMessage.text = failure.message
}
